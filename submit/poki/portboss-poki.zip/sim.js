/* HARBOR — render-agnostic economy simulation. window.HARBOR_SIM
 * No WebGL/DOM here so it runs headlessly (Node tests) and the renderer just reads state.
 *
 * EMPIRE + PORTS model (Phase 4): one empire (shared money + era + managers) owns many PORTS,
 * one per founded world (biomeId). Each port has its own resources, buildings, demand and market.
 * Worlds specialise (WORLD_SPEC) so cross-island trade matters: e.g. the Desert makes goods but no
 * timber. tick() advances every founded port, accrues to the shared treasury, then runs the trade
 * network (4b) and hazards (4c). Reaching money+building thresholds advances the empire era, which
 * unlocks new worlds and building tiers. Persists + accrues offline via Retention.
 */
(function (g) {
  'use strict';
  var R = g.Retention || null;

  // Seedable RNG: all gameplay randomness routes through _rng so tests can make
  // events / voyages / crates deterministic via HARBOR_SIM.__setRng(fn). Defaults to Math.random.
  var _rng = Math.random;
  function setRng(fn) { _rng = (typeof fn === 'function') ? fn : Math.random; }

  // Phase 15b: PACE — a player-facing multiplier on how often storms/events roll around. Lives on
  // the module (NOT the save blob — it's a device preference, same as sound/haptics) so it never
  // needs a save-format migration and applies identically whether you're mid-game or freshly booted.
  // Scales ONLY the gap rolls between hazards/events (hzRand/evRand) — production, sales, voyage
  // timers and every other economy rate are untouched, so Relaxed truly just spaces out the scary
  // stuff rather than slowing the whole game down (that's what playtesters actually asked for).
  var PACE = 1;
  function setPace(m) { PACE = (typeof m === 'number' && m > 0) ? m : 1; }

  // ---- DIFFICULTY (Easy→Extreme) ----
  // Harder tiers slow income, shrink event/hazard gaps (more storms + wars), hit harder, weight raids
  // up, and cap offline earnings — so passive idling can't keep up and you MUST actively defend
  // (sea walls / navy / lighthouses), avert hazards, and trade for blocked resources. Harder play
  // banks more prestige Legacy (the reward for strategy). Easy = every lever 1.0 → an exact no-op, so
  // today's balance + all existing tests are unchanged. Injected like PACE/META; persisted in game.js.
  var DIFFS = {
    easy:    { name: 'Easy',    income: 1.0,  gap: 1.0,  severity: 1.0, raidW: 1.0, offlineHours: 8, prestigeMul: 1.0, desc: 'Relaxed — build at your own pace' },
    hard:    { name: 'Hard',    income: 0.7,  gap: 0.75, severity: 1.4, raidW: 1.5, offlineHours: 6, prestigeMul: 1.3, desc: 'Leaner cash, more storms & raids' },
    brutal:  { name: 'Brutal',  income: 0.5,  gap: 0.55, severity: 1.9, raidW: 2.2, offlineHours: 4, prestigeMul: 1.7, desc: 'Harsh economy, frequent disasters' },
    extreme: { name: 'Extreme', income: 0.35, gap: 0.4,  severity: 2.6, raidW: 3.0, offlineHours: 2, prestigeMul: 2.3, desc: 'Idling fails — defend or sink' }
  };
  var DIFF_ID = 'easy', DIFF = DIFFS.easy;
  function setDifficulty(id) { if (DIFFS[id]) { DIFF_ID = id; DIFF = DIFFS[id]; } }
  function difficultyView() { var o = { id: DIFF_ID, tiers: [] }; for (var k in DIFFS) { o.tiers.push({ id: k, name: DIFFS[k].name, desc: DIFFS[k].desc, prestigeMul: DIFFS[k].prestigeMul }); if (DIFFS[k] === DIFF) { o.name = DIFFS[k].name; o.desc = DIFFS[k].desc; o.prestigeMul = DIFFS[k].prestigeMul; } } return o; }

  // ---- era ladder (empire rank) ----
  // Phase 17a: extended past Global Hub with two technology ages — Automated Harbour (robots +
  // logistics take over the docks) and Neon Horizon (the harbour of tomorrow: solar/fusion power,
  // holographic markets). eraName()'s roman-numeral endless tail now continues past Neon Horizon
  // ("Neon Horizon II"…) exactly as it used to continue past Global Hub.
  var ERAS = ['Fishing Village', 'Trading Post', 'Industrial Port', 'Metropolis', 'Megaport', 'Global Hub', 'Automated Harbour', 'Neon Horizon'];

  // ---- building catalogue (data-driven) ----
  // prod: {res:rate/s}; sells:{from,rate/s,price}; money:rate/s (direct trade); cap:{res:amount};
  // pop: housing added; jobs: workers needed; era: min era to build; cost/costMul: build price growth;
  // lvlCost: upgrade price growth; lvlGain: per-level output multiplier.
  var BT = {
    fishing_hut: { name: 'Fishing Hut', era: 0, cost: 25, costMul: 1.5, jobs: 2, cat: 'prod', prod: { fish: 0.5 }, lvlCost: 1.58, lvlGain: 1.38, max: 12 },
    jetty:       { name: 'Fishing Jetty', era: 0, cost: 60, costMul: 1.5, jobs: 1, cat: 'sales', sells: { from: 'fish', rate: 0.9, price: 3 }, lvlCost: 1.62, lvlGain: 1.36, max: 12 },
    cottage:     { name: 'Cottage', era: 0, cost: 40, costMul: 1.46, pop: 4, lvlCost: 1.55, lvlGain: 1.35, max: 24 },
    warehouse:   { name: 'Warehouse', era: 1, cost: 120, costMul: 1.55, cap: { fish: 90, timber: 90, goods: 90 }, lvlCost: 1.62, lvlGain: 1.42, max: 12 },
    market:      { name: 'Fish Market', era: 1, cost: 160, costMul: 1.55, jobs: 3, cat: 'sales', sells: { from: 'fish', rate: 1.6, price: 4.5 }, lvlCost: 1.64, lvlGain: 1.38, max: 12 },
    sawmill:     { name: 'Sawmill', era: 2, cost: 320, costMul: 1.55, jobs: 4, cat: 'prod', prod: { timber: 0.8 }, lvlCost: 1.66, lvlGain: 1.4, max: 12 },
    factory:     { name: 'Goods Factory', era: 2, cost: 520, costMul: 1.58, jobs: 6, cat: 'prod', convert: { from: 'timber', to: 'goods', rate: 0.7 }, lvlCost: 1.68, lvlGain: 1.4, max: 12 },
    dock:        { name: 'Cargo Dock', era: 2, cost: 800, costMul: 1.6, jobs: 5, cat: 'sales', sells: { from: 'goods', rate: 0.7, price: 22 }, lvlCost: 1.7, lvlGain: 1.42, max: 12 },
    // defenses (no output) — Sea Wall cuts storm damage to this port; Lighthouse cuts route cargo loss
    seawall:     { name: 'Sea Wall', era: 1, cost: 200, costMul: 1.6, cat: 'defense', def: 'wall', lvlCost: 1.55, lvlGain: 1.0, max: 5 },
    lighthouse:  { name: 'Lighthouse', era: 2, cost: 300, costMul: 1.7, cat: 'defense', def: 'light', lvlCost: 1.6, lvlGain: 1.0, max: 3 },

    // Phase 17a: Age 6 — Automated Harbour (era 6). Eras 3-5 (Metropolis/Megaport/Global Hub) never
    // added new building TYPES — they only asked for more of the era-2 set — so these are the first
    // new buildings since Industrial Port. Robo-Crane also gives timber its first direct sale outlet
    // (previously timber only ever fed the sawmill→factory convert chain).
    container_terminal: { name: 'Container Terminal', era: 6, cost: 6000, costMul: 1.62, jobs: 9, cat: 'sales', sells: { from: 'goods', rate: 2.4, price: 150 }, lvlCost: 1.72, lvlGain: 1.42, max: 12 },
    drone_bay:          { name: 'Drone Bay', era: 6, cost: 9000, costMul: 1.64, jobs: 0, cat: 'prod', convert: { from: 'timber', to: 'goods', rate: 5.5 }, lvlCost: 1.74, lvlGain: 1.42, max: 12 },
    robo_crane:         { name: 'Robo-Crane', era: 6, cost: 5000, costMul: 1.6, jobs: 5, cat: 'sales', sells: { from: 'timber', rate: 3.4, price: 55 }, lvlCost: 1.7, lvlGain: 1.4, max: 12 },
    logistics_hub:      { name: 'Logistics Hub', era: 6, cost: 8000, costMul: 1.66, cap: { fish: 500, timber: 500, goods: 500 }, lvlCost: 1.7, lvlGain: 1.35, max: 12 },

    // Phase 17a: Age 7 — Neon Horizon (era 7). Solar Spire is the game's first building to use the
    // `money` field (direct £/s income — see tickPort()): it needs no resource to sell, so it's
    // immune to demand-softening AND market crashes, a genuine "harbour of tomorrow" perk. Sky
    // Beacon is a fourth defense tier, stacking with Sea Wall/Lighthouse/network insurance (see
    // portDef()/strike()/evData('raid') below).
    solar_spire: { name: 'Solar Spire', era: 7, cost: 55000, costMul: 1.65, jobs: 0, cat: 'money', money: 34, lvlCost: 1.75, lvlGain: 1.45, max: 10 },
    holo_market: { name: 'Holo-Market', era: 7, cost: 45000, costMul: 1.6, jobs: 10, cat: 'sales', sells: { from: 'fish', rate: 6.0, price: 220 }, lvlCost: 1.72, lvlGain: 1.42, max: 12 },
    fusion_dock: { name: 'Fusion Dock', era: 7, cost: 60000, costMul: 1.62, jobs: 12, cat: 'sales', sells: { from: 'goods', rate: 3.2, price: 620 }, lvlCost: 1.74, lvlGain: 1.44, max: 12 },
    sky_beacon:  { name: 'Sky Beacon', era: 7, cost: 70000, costMul: 1.8, cat: 'defense', def: 'beacon', lvlCost: 1.65, lvlGain: 1.0, max: 5 }
  };
  var BASE_CAP = { fish: 80, timber: 80, goods: 80 };

  // ---- world specialisation (per founded world) ----
  // Production multipliers per resource + a one-line hint. A 0 multiplier means the world cannot
  // produce that resource at all (its pure-producer buildings are blocked) — forcing trade imports.
  var WORLD_SPEC = {
    green:    { fish: 1.0, timber: 1.0, goods: 1.0, hint: 'Balanced home waters' },
    mountain: { fish: 0.8, timber: 1.6, goods: 0.9, hint: 'Timber-rich fjords' },
    desert:   { fish: 0.7, timber: 0.0, goods: 1.4, hint: 'Industrial — imports timber' },
    tropical: { fish: 1.5, timber: 0.7, goods: 1.1, hint: 'Teeming fisheries' },
    nordic:   { fish: 1.1, timber: 1.3, goods: 1.2, hint: 'Hardy heavy industry' }
  };
  var WORLD_ORDER = ['green', 'mountain', 'desert', 'tropical', 'nordic'];
  function spec(id) { return WORLD_SPEC[id] || WORLD_SPEC.green; }

  // ---- building synergies (Phase 9a) ----
  // Count-based (NOT spatial): a per-port multiplier read from the port's building COMPOSITION.
  // Modest, stackable bonuses that turn "spend money" into an optimisation puzzle. chan: 'prod'|'sales'.
  var SYNERGY_DEFS = [
    { id: 'tradehub',  name: 'Trade Hub',   effect: '+12% sales',      chan: 'sales', amt: 0.12, test: function (c) { return (c.warehouse || 0) >= 1 && (c.market || 0) >= 1; } },
    { id: 'boomtown',  name: 'Boomtown',    effect: '+15% production', chan: 'prod',  amt: 0.15, test: function (c) { return (c.cottage || 0) >= 3; } },
    { id: 'millforge', name: 'Mill & Forge', effect: '+15% goods',     chan: 'prod',  amt: 0.15, test: function (c) { return (c.sawmill || 0) >= 1 && (c.factory || 0) >= 1; } },
    { id: 'freeport',  name: 'Free Port',   effect: '+10% sales',      chan: 'sales', amt: 0.10, test: function (c) { return (c.market || 0) >= 1 && (c.dock || 0) >= 1; } },
    // Phase 17a: Automated Harbour's pair — a crew-free convert building + the timber loading crane
    { id: 'automation', name: 'Automated Line', effect: '+18% production', chan: 'prod', amt: 0.18, test: function (c) { return (c.drone_bay || 0) >= 1 && (c.robo_crane || 0) >= 1; } }
  ];
  var SYN_MAX = 1.6;                                   // clamp: synergies stack but never runaway
  function portCounts(port) { var c = {}, B = port.buildings || []; for (var i = 0; i < B.length; i++) { var t = B[i].type; c[t] = (c[t] || 0) + 1; } return c; }
  // pure: given a port, return {prod, sales} composition multipliers (no CUR / DOM dependency)
  function synergyMul(port) {
    var c = portCounts(port), prod = 1, sales = 1;
    for (var i = 0; i < SYNERGY_DEFS.length; i++) { var d = SYNERGY_DEFS[i]; if (d.test(c)) { if (d.chan === 'sales') sales += d.amt; else prod += d.amt; } }
    return { prod: Math.min(prod, SYN_MAX), sales: Math.min(sales, SYN_MAX) };
  }
  function synergyList(port) {
    var c = portCounts(port);
    return SYNERGY_DEFS.map(function (d) { return { id: d.id, name: d.name, effect: d.effect, chan: d.chan, active: !!d.test(c) }; });
  }

  // ---- port specialisation / focus (Phase 9a) ----
  // A per-port pickable tradeoff. Default 'none'. Applied inside tickPort alongside synergies.
  var FOCUS_IDS = ['none', 'fishing', 'industry', 'trade'];
  var FOCUS_DEFS = [
    { id: 'none',     name: 'Balanced', effect: 'Even output — no bias' },
    { id: 'fishing',  name: 'Fishing',  effect: '+25% fish, −15% goods' },
    { id: 'industry', name: 'Industry', effect: '+25% goods, −15% fish' },
    { id: 'trade',    name: 'Trade',    effect: '+15% sales & routes, −10% raw' }
  ];
  // per-resource production multiplier for a focus (raw = fish/timber; goods is manufactured)
  function focusProdMul(focus, res) {
    if (focus === 'fishing') return res === 'fish' ? 1.25 : (res === 'goods' ? 0.85 : 1);
    if (focus === 'industry') return res === 'goods' ? 1.25 : (res === 'fish' ? 0.85 : 1);
    if (focus === 'trade') return (res === 'fish' || res === 'timber') ? 0.90 : 1;   // −10% raw extraction
    return 1;
  }
  function focusSalesMul(focus) { return focus === 'trade' ? 1.15 : 1; }
  function focusRouteMul(focus) { return focus === 'trade' ? 1.15 : 1; }

  // managers: permanent EMPIRE-WIDE multipliers bought with money (a real spend sink)
  var MANAGERS = {
    fishing: { name: 'Master Angler', desc: '+18% all production', cost: 200, costMul: 1.85, per: 0.18, max: 10 },
    sales:   { name: 'Harbourmaster', desc: '+16% all sales', cost: 240, costMul: 1.9, per: 0.16, max: 10 },
    labour:  { name: 'Foreman', desc: '+15% labour, −10% wages', cost: 220, costMul: 1.88, per: 0.15, max: 10 }
  };
  var WAGE = 0.10, DEMAND_SOFT = 14;   // wage/worker/s; sales/s above which demand price softens

  // era advance requirements: money on hand + minimum building counts (EMPIRE-wide counts)
  // Phase 17a: two new gates continue the ~5-7x money curve past Megaport's 40000: index5 (Global
  // Hub -> Automated Harbour) needs a proven era2 industrial base (no era3-5 buildings ever existed
  // to gate on, so — like the Megaport/Global Hub gates before it — this reuses dock/factory counts);
  // index6 (Automated Harbour -> Neon Horizon) is the first gate to require NEW-age buildings, since
  // Automated Harbour is the first age since Industrial Port to actually add any. Numbers: 200000 ->
  // 300000 (1.5x — Global Hub itself was already the "prove you're industrial" gate) -> 2000000
  // (6.67x, back on the established 5-7x/step curve) — see the commit body for the autoplay this was
  // checked against.
  var ERA_REQ = [
    { money: 250, need: { fishing_hut: 2, cottage: 1 } },           // -> Trading Post
    { money: 1500, need: { jetty: 1, cottage: 2 } },                // -> Industrial Port
    { money: 8000, need: { warehouse: 1, market: 1 } },             // -> Metropolis
    { money: 40000, need: { factory: 1, dock: 1 } },                // -> Megaport
    { money: 200000, need: { dock: 2 } },                           // -> Global Hub
    { money: 300000, need: { dock: 3, factory: 2 } },               // -> Automated Harbour
    { money: 2000000, need: { container_terminal: 1, drone_bay: 1 } }  // -> Neon Horizon
  ];
  // ENDLESS eras: past the curated ladder, generate "Neon Horizon II, III…" with exponentially
  // scaling money thresholds (continuing the same 6x/step the curated gates settle into), so the
  // ladder never ends (prestige multipliers keep you climbing it).
  var ERA_TAIL_MUL = 6;
  function roman(n) {
    if (n < 1) return '' + n;
    var M = ['', 'M', 'MM', 'MMM'], C = ['', 'C', 'CC', 'CCC', 'CD', 'D', 'DC', 'DCC', 'DCCC', 'CM'],
        X = ['', 'X', 'XX', 'XXX', 'XL', 'L', 'LX', 'LXX', 'LXXX', 'XC'], I = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX'];
    if (n > 3999) return '' + n;
    return M[(n / 1000) | 0] + C[((n % 1000) / 100) | 0] + X[((n % 100) / 10) | 0] + I[n % 10];
  }
  function eraName(n) { return n < ERAS.length ? ERAS[n] : 'Neon Horizon ' + roman(n - ERAS.length + 2); }
  function eraReq(n) {
    if (n < ERA_REQ.length) return ERA_REQ[n];
    var lastMoney = ERA_REQ[ERA_REQ.length - 1].money;
    return { money: Math.round(lastMoney * Math.pow(ERA_TAIL_MUL, n - (ERA_REQ.length - 1))) };
  }

  // ---- Phase 17b: FLEET REGISTRY — three empire-wide ship-tier ladders (fishing/trade/expedition),
  // one tier index 0-7 each, aligned 1:1 with the age ladder (ERAS[0..7] above): tier t needs
  // era >= t and tiers must be bought IN ORDER (t = current+1 only, no skipping) — you can't own a
  // Neon Horizon hull without ever having modernised the eras before it. Purely a money sink + a
  // production/income rubber-band (fleetYieldMul below); it never blocks play, and models.js/game.js
  // read the tier to pick which SHIPYARD class silhouette actually sails the harbour.
  //
  // Cost table: tier0 is free (the starting village already has boats). Tiers 3-7 are exactly
  // eraReq(t-1).money / 4 — the era-up gate one step earlier, quartered, so a fleet upgrade always
  // reads as "a meaningful fraction of what it took to reach this age", never a throwaway tap. Tiers
  // 1-2 are nudged ABOVE their raw quarter (250/4=62.5, 1500/4=375) to £120/£450 — early game money
  // moves fast enough that a sub-£100 upgrade would feel free; £120/£450 keep them felt without
  // being a wall. Table: [0, 120, 450, 2000, 10000, 50000, 75000, 500000].
  var FLEET_ROLES = ['fishing', 'trade', 'expedition'];
  var FLEET_COST = [0, 120, 450, 2000, 10000, 50000, 75000, 500000];
  var FLEET_MAX_TIER = FLEET_COST.length - 1;   // 7 — matches ERAS.length-1 (Neon Horizon)
  function fleetTier(role) { return (S && S.fleetTech && S.fleetTech[role]) || 0; }
  function fleetShipCost(role) {
    var t = fleetTier(role);
    return t >= FLEET_MAX_TIER ? null : FLEET_COST[t + 1];
  }
  function fleetEraGated(role) { var t = fleetTier(role); return t < FLEET_MAX_TIER && empireEra() < t + 1; }
  function canBuyShip(role) {
    if (!S || FLEET_ROLES.indexOf(role) < 0) return false;
    var t = fleetTier(role);
    return t < FLEET_MAX_TIER && empireEra() >= t + 1 && S.money >= FLEET_COST[t + 1];   // fleet is empire-wide → gate on your most advanced harbour
  }
  function buyShip(role) {
    if (!canBuyShip(role)) return false;
    var t = fleetTier(role);
    S.money -= FLEET_COST[t + 1];
    S.fleetTech[role] = t + 1;
    S.stats.shipsBought = (S.stats.shipsBought || 0) + 1;
    save(); return true;
  }
  // Phase 17b yield formula — a gentle rubber-band, never a hard block: owning the current age's
  // fleet (tier === era) is worth +10%/age above baseline; falling behind costs -5%/age behind,
  // floored so an old fleet never cripples you outright. tier is always <= era (tiers require
  // era >= t to buy) so min(tier,era)=tier and max(0,era-tier) is simply the "ages behind" count —
  // written with the min/max form anyway so the formula stays correct even if that invariant is
  // ever relaxed. EXACT formula (asserted in tests/sim.test.js):
  //   mul = clamp(1 + 0.10 * min(tier, era) - 0.05 * max(0, era - tier), 0.85, 1.8)
  // e.g. era2/tier2 (current) = 1.20; era2/tier0 (2 ages behind) = 0.90 → owning the current age's
  // fleet is +33% relative to being 2 ages behind, matching the "+25-35%" target across the ladder;
  // era0/tier0 (a fresh or freshly-migrated save) = 1.00 exactly — no regression vs pre-17b income.
  var FLEET_MUL_MIN = 0.85, FLEET_MUL_MAX = 1.8;
  function fleetYieldMul(role) {
    if (!S) return 1;
    var tier = fleetTier(role), erax = S.era || 0;
    var v = 1 + 0.10 * Math.min(tier, erax) - 0.05 * Math.max(0, erax - tier);
    return clamp(v, FLEET_MUL_MIN, FLEET_MUL_MAX);
  }
  // fishing fleet only rubber-bands FISH extraction (a modern trawler catches more fish; it doesn't
  // make a sawmill saw faster) — every other resource's production multiplier stays 1.
  function fleetProdMul(res) { return res === 'fish' ? fleetYieldMul('fishing') : 1; }

  // ---- Phase 17c: THE NAVY — a 5-rung, era-gated DEFENSE ladder (S.navy 0-5) alongside the 17b
  // fleet ladders above. Where fleet-tech is a production rubber-band, the Navy is pure harbour
  // DEFENSE: it auto-repels raids outright once navyPower catches up to how dangerous raids have
  // become (raidStrength, era-scaled — "the harbourmaster has to keep up with the times"), nudges
  // the manual raid-fight winOdds, and trims storm damage (hazardResist) — composing with, never
  // replacing, the existing Sea Wall/Lighthouse/Sky Beacon/Legacy defenses (portDef()/strike()/
  // evData('raid') below). No upkeep: once bought, a class stays on patrol for free — a pure
  // one-time money sink + a permanent safety net, exactly as idle-friendly as the rest of the
  // defense stack.
  //
  // Ladder (bought strictly in order, one class at a time, era-gated): 1 Patrol Cutter (era>=1),
  // 2 Frigate (era>=2), 3 Ironclad (era>=4), 4 Destroyer (era>=5), 5 Drone Screen (era>=6) — the
  // era gate deliberately SKIPS era3 (no new rung at Metropolis, mirroring how eras 3-5 never
  // added new BUILDING types either — see BT's Phase 17a comment above) and the ladder tops out a
  // full age early (era6, Automated Harbour) rather than waiting for Neon Horizon/era7 — the
  // "harbour of tomorrow" drone screen is deliberately the Navy's own capstone, not a mirror of
  // the fleet ladders' 8th rung.
  //
  // Cost table: [—, 300, 1500, 12000, 90000, 400000] — steeper than the fleet-tech ladder
  // (FLEET_COST above) at every step it overlaps: a navy tier is a permanent safety net (never
  // revenue), so it should read as a heavier, more deliberate spend than a same-age production
  // upgrade — roughly 2.5x FLEET_COST at tiers 1-2 (fleet £120/£450 vs navy £300/£1500), settling
  // to a comparable order of magnitude by the top (fleet caps at £500000, navy at £400000) once
  // raids are a late-game inconvenience either way.
  var NAVY_CLASSES = ['patrol_cutter', 'frigate', 'ironclad', 'destroyer', 'drone_screen'];
  var NAVY_COST = [0, 300, 1500, 12000, 90000, 400000];        // index = tier; index0 unused (tier0 = no navy)
  var NAVY_ERA = [0, 1, 2, 4, 5, 6];                            // era required to OWN tier i (index = tier)
  var NAVY_MAX_TIER = NAVY_COST.length - 1;                    // 5
  function navyTier() { return (S && S.navy) || 0; }
  function navyShipCost() { var t = navyTier(); return t >= NAVY_MAX_TIER ? null : NAVY_COST[t + 1]; }
  function navyEraGated() { var t = navyTier(); return t < NAVY_MAX_TIER && empireEra() < NAVY_ERA[t + 1]; }
  function canBuyNavy() {
    if (!S) return false;
    var t = navyTier();
    return t < NAVY_MAX_TIER && empireEra() >= NAVY_ERA[t + 1] && S.money >= NAVY_COST[t + 1];   // navy is empire-wide
  }
  function buyNavy() {
    if (!canBuyNavy()) return false;
    var t = navyTier();
    S.money -= NAVY_COST[t + 1];
    S.navy = t + 1;
    S.stats.navyBought = (S.stats.navyBought || 0) + 1;
    save(); return true;
  }
  // navyPower(): deliberately the simplest possible read — tier IS power, no separate formula to
  // tune. Every downstream effect (raidStrength threshold, winOdds bonus, hazardResist) scales off
  // this one number.
  function navyPower() { return navyTier(); }
  // raidStrength: how dangerous a raid has become by this era — the auto-defense threshold
  // navyPower must MEET OR BEAT for the harbour to repel a raid outright with no modal. Scales +1
  // every 2 eras (era0-1 -> 1, era2-3 -> 2, era4-5 -> 3, era6-7 -> 4…) so a maxed navyPower=5 keeps
  // auto-repelling raids all the way through era8-9 before the harbourmaster has to modernise the
  // navy again — "keep up with the times", not "buy once and forget forever".
  function raidStrength() { return 1 + Math.floor((S.era || 0) / 2); }
  function navyView() {
    var t = navyTier(), cost = navyShipCost();
    return { tier: t, cost: cost, power: navyPower(), can: canBuyNavy(), eraGated: navyEraGated(), maxed: cost == null, nextEra: cost == null ? null : eraName(NAVY_ERA[t + 1]) };
  }

  // META: permanent cross-prestige multipliers (computed in game.js from the Legacy tree, fed in via
  // applyMeta so the sim stays headless-testable). Defaults are the no-prestige baseline.
  var META = { prodMul: 1, sellMul: 1, costMul: 1, startMoney: 0, offlineHours: 8, hazardResist: 0, routeMul: 1, voyageSpeed: 1, voyageSlots: 0, contractSlots: 0, voyageYield: 0 };
  function applyMeta(m) { if (!m) return; for (var k in META) if (typeof m[k] === 'number') META[k] = m[k]; if (CUR) ensureContracts(); }   // Phase 9c: Monopoly capstone widens the contract board live

  // TIDE: today's daily market modifier (computed in game.js from the seeded daily RNG, fed in here).
  // A rotating positive bonus that rewards logging in — production and/or per-resource sale boosts.
  var TIDE = { prod: 1, sell: { fish: 1, timber: 1, goods: 1 } };
  function setTide(t) { if (!t) return; TIDE.prod = t.prod || 1; TIDE.sell = { fish: (t.sell && t.sell.fish) || 1, timber: (t.sell && t.sell.timber) || 1, goods: (t.sell && t.sell.goods) || 1 }; }
  // BOOST: a transient production surge (e.g. from opening a crate). Not persisted — pure live juice.
  var BOOST = { mult: 1, t: 0 };
  function setBoost(mult, secs) { BOOST.mult = mult || 1; BOOST.t = secs || 0; }
  function boostMul() { return BOOST.t > 0 ? BOOST.mult : 1; }

  var S = null;     // empire root
  var CUR = null;   // the port currently in scope for the per-port helpers below
  function now() { return Date.now ? Date.now() : 0; }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  // ---- construction ----
  function freshPort(id) {
    return {
      id: id, era: 0, res: { fish: 0, timber: 0, goods: 0 }, buildings: [], pop: 0, focus: 'none',
      demand: { fish: 1, timber: 1, goods: 1 }, contracts: [], contractSeq: 0
    };
  }
  function fresh() {
    return {
      era: 0, money: 150 + (META.startMoney || 0), lifetimeMoney: 0, lastSeen: now(), founded: false,
      managers: { fishing: 0, sales: 0, labour: 0 },
      active: 'green', ports: {},
      network: { xp: 0, level: 1, routes: [] },
      hazard: { t: 0, next: hzRand(70, 150), phase: 'idle', strikeId: 0, last: null }, crash: null,
      evt: { t: 0, next: evRand(60, 130), active: null, lastId: '', seq: 0 },
      voyages: [], voyageSeq: 0,
      fleetTech: { fishing: 0, trade: 0, expedition: 0 },     // Phase 17b: fleet registry tiers
      navy: 0, lastNavyRepel: null,                           // Phase 17c: navy tier + last auto-defense (for the game.js banner)
      stats: { storms: 0, shipped: 0, averted: 0, shipsBought: 0, navyBought: 0, raidsRepelled: 0 }
    };
  }
  // Per-port era: each harbour advances on its own; S.era mirrors the ACTIVE port's era so every
  // existing S.era read (build gates, slot cap, advance, contracts, HUD) means "this harbour's age".
  function setActive(id) {
    // Only pull S.era from the port when the ACTIVE port actually changes (a real world switch).
    // The many defensive setActive(S.active) re-sync calls (fireEvent/resolveEvent/tick cleanup) pass
    // the current active id and must NOT reload S.era — S.era already tracks it, and advanceEra/setEra
    // are the authorities that move an active port's era. (tick clobbers CUR across ports; these calls
    // just re-point it — they never went stale on era.)
    var switching = (id != null && id !== S.active);
    if (id != null) S.active = id;
    CUR = (S.ports && S.ports[S.active]) || null;
    if (switching && CUR && typeof CUR.era === 'number') S.era = CUR.era;
  }
  // Empire era = the most advanced harbour you own (with S.era as a floor for robustness). Empire-wide
  // systems (fleet, navy, expedition slots, colony cost, the Uncharted-Waters discovery gate) key off
  // THIS, not the active port — so a fresh era-0 colony never rolls back your fleet tech or discovery.
  function empireEra() { var m = (S && S.era) || 0; if (S && S.ports) for (var pid in S.ports) { var e = S.ports[pid].era || 0; if (e > m) m = e; } return m; }

  // migrate older saves (incl. the pre-Phase-4 single-global economy) into empire+ports shape
  function patch() {
    if (!S) return;
    if (!S.managers) S.managers = { fishing: 0, sales: 0, labour: 0 };
    if (typeof S.lifetimeMoney !== 'number') S.lifetimeMoney = 0;
    if (typeof S.money !== 'number') S.money = 120;
    if (typeof S.era !== 'number') S.era = 0;
    if (!S.network) S.network = { xp: 0, level: 1, routes: [] };
    // LEGACY: a pre-Phase-4 save kept res/buildings/demand at the top level — wrap into one port.
    if (S.res && S.buildings && !S.ports) {
      var lid = S.active || 'green';
      var lp = freshPort(lid);
      lp.res = S.res; lp.buildings = S.buildings;
      lp.demand = S.demand || { fish: 1, timber: 1, goods: 1 };
      lp.contracts = S.contracts || []; lp.contractSeq = S.contractSeq || 0; lp.pop = S.pop || 0;
      S.ports = {}; S.ports[lid] = lp; S.active = lid;
      delete S.res; delete S.buildings; delete S.demand; delete S.contracts; delete S.contractSeq; delete S.pop;
    }
    if (!S.ports) S.ports = {};
    if (!S.active) S.active = 'green';
    for (var id in S.ports) {
      var pt = S.ports[id];
      if (!pt.id) pt.id = id;
      if (typeof pt.era !== 'number') pt.era = S.era || 0;            // per-port era: existing saves' harbours keep the old global era
      if (!pt.res) pt.res = { fish: 0, timber: 0, goods: 0 };
      if (!pt.demand) pt.demand = { fish: 1, timber: 1, goods: 1 };
      if (!pt.buildings) pt.buildings = [];
      if (FOCUS_IDS.indexOf(pt.focus) < 0) pt.focus = 'none';   // backfill port specialisation on old saves
      if (!pt.contracts) pt.contracts = [];
      if (typeof pt.contractSeq !== 'number') pt.contractSeq = 0;
      for (var bi = 0; bi < pt.buildings.length; bi++) if (pt.buildings[bi].hp == null) pt.buildings[bi].hp = 100;
      CUR = pt; ensureContracts();
    }
    if (!S.hazard) S.hazard = { t: 0, next: hzRand(70, 150), phase: 'idle', strikeId: 0, last: null };
    if (!S.evt) S.evt = { t: 0, next: evRand(60, 130), active: null, lastId: '', seq: 0 };
    if (!S.voyages) S.voyages = [];
    if (typeof S.crash === 'undefined') S.crash = null;
    if (!S.stats) S.stats = { storms: 0 };
    if (typeof S.stats.shipped !== 'number') S.stats.shipped = 0;
    if (typeof S.stats.averted !== 'number') S.stats.averted = 0;   // Phase 15b: additive backfill — old saves load fine
    if (typeof S.stats.shipsBought !== 'number') S.stats.shipsBought = 0;   // Phase 17b: additive backfill
    if (!S.fleetTech) S.fleetTech = { fishing: 0, trade: 0, expedition: 0 };   // Phase 17b: old saves start every ladder at tier 0
    else FLEET_ROLES.forEach(function (r) { if (typeof S.fleetTech[r] !== 'number') S.fleetTech[r] = 0; });
    if (typeof S.navy !== 'number') S.navy = 0;                               // Phase 17c: old saves start with no navy
    if (typeof S.lastNavyRepel === 'undefined') S.lastNavyRepel = null;
    if (typeof S.stats.navyBought !== 'number') S.stats.navyBought = 0;
    if (typeof S.stats.raidsRepelled !== 'number') S.stats.raidsRepelled = 0;
    setActive(S.active);
  }

  // ---- per-port helpers (operate on CUR) ----
  function counts() { var c = {}, B = CUR.buildings; for (var i = 0; i < B.length; i++) { var t = B[i].type; c[t] = (c[t] || 0) + 1; } return c; }
  function countOf(type) { var n = 0, B = CUR.buildings; for (var i = 0; i < B.length; i++) if (B[i].type === type) n++; return n; }
  function empireCounts() { var c = {}; for (var id in S.ports) { var B = S.ports[id].buildings; for (var i = 0; i < B.length; i++) { var t = B[i].type; c[t] = (c[t] || 0) + 1; } } return c; }
  function capsOf(port) {
    var cap = { fish: BASE_CAP.fish, timber: BASE_CAP.timber, goods: BASE_CAP.goods }, B = port.buildings;
    for (var i = 0; i < B.length; i++) { var b = B[i], t = BT[b.type]; if (t.cap) for (var r in t.cap) cap[r] += t.cap[r] * lvlMul(t, b.level); }
    return cap;
  }
  function caps() { return capsOf(CUR); }
  function pop() { var p = 0, B = CUR.buildings; for (var i = 0; i < B.length; i++) { var b = B[i], t = BT[b.type]; if (t.pop) p += t.pop * lvlMul(t, b.level); } return p; }
  // jobs scale with level (bigger buildings need more crew) — keeps housing meaningful late game
  function jobs() { var j = 0, B = CUR.buildings; for (var i = 0; i < B.length; i++) { var b = B[i], t = BT[b.type]; if (t.jobs) j += t.jobs * (1 + 0.5 * ((b.level || 1) - 1)); } return j; }
  function lvlMul(t, lvl) { return Math.pow(t.lvlGain, (lvl || 1) - 1); }
  // economic buildings are effectively uncapped PER TYPE (geometric cost self-limits, and upgrade
  // levels reuse this same ceiling so it must stay permissive); defenses keep tight per-type caps.
  function bmax(type) { var t = BT[type]; return t.cat === 'defense' ? t.max : Math.max(t.max, 999); }
  // v90: per-era UPGRADE-LEVEL ceiling for economic buildings. Each age lets you push a building two
  // levels past L1 plus one per era reached: era0 Fishing Village -> L2, era3 Metropolis -> L5,
  // era7 Neon Horizon -> L9, endless tail keeps climbing. Defenses keep their own tight per-type max
  // (bmax). This is what turns "advance = pile up money" into "advance = MASTER this age's buildings
  // (upgrade them to the cap), THEN move up to unlock higher levels" — see canAdvance's countAtCap gate.
  var LVL_CAP_BASE = 2;
  function lvlCap() { return LVL_CAP_BASE + (S.era || 0); }
  function lvlCapFor(type) { var t = BT[type]; return t.cat === 'defense' ? t.max : lvlCap(); }
  // copies of `type` this port has upgraded all the way to the current era's cap — the advancement
  // gate counts these, so a required building only "counts" toward the next age once it's maxed.
  function countAtCap(port, type) { var B = port.buildings, cap = lvlCapFor(type), n = 0; for (var i = 0; i < B.length; i++) if (B[i].type === type && (B[i].level || 1) >= cap) n++; return n; }
  // Phase 15c: total non-defense building SLOTS per port — replaces "ports grow forever" with a
  // real, era-scaled ceiling. Deliberately independent of bmax(): bmax also gates upgrade LEVELS
  // (canUpgrade below), and per-type build counts still self-limit on cost, so touching it would
  // accidentally cap upgrades too. This is a second, additive gate — only non-defense buildings
  // (defenses keep their own tight bmax caps and don't compete with them for room) count against it.
  // Tuning: 8 + 4×era. At era0 that covers a full starter loop (a few huts/cottages + a jetty) with
  // room to spare; +4/era roughly tracks the 2-4 new building types each era unlocks, so there's
  // always headroom for one of everything plus some duplicates. See tests/sim.test.js + the Phase 15c
  // commit body for the autoplay numbers this was checked against.
  var SLOT_BASE = 8, SLOT_PER_ERA = 4;
  function slotCap() { return SLOT_BASE + SLOT_PER_ERA * (S.era || 0); }
  function slotsUsed(port) {
    port = port || CUR; if (!port) return 0;
    var n = 0, B = port.buildings;
    for (var i = 0; i < B.length; i++) if (BT[B[i].type].cat !== 'defense') n++;
    return n;
  }
  function buildCost(type) { var t = BT[type]; return Math.round(t.cost * Math.pow(t.costMul, countOf(type)) * (META.costMul || 1)); }
  function upCost(b) { var t = BT[b.type]; return Math.round(t.cost * 0.6 * Math.pow(t.lvlCost, b.level) * (META.costMul || 1)); }
  // a building is blocked on this world if every resource it produces has a 0 specialisation
  function blocked(type) {
    var t = BT[type]; if (!t || !t.prod) return false;
    var sp = spec(S.active), any = false;
    for (var r in t.prod) if (sp[r] > 0) any = true;
    return !any;
  }

  // ---- managers (empire-wide multiplier upgrades; a real money sink) ----
  function managerCost(kind) { var m = MANAGERS[kind]; if (!m) return Infinity; return Math.round(m.cost * Math.pow(m.costMul, (S.managers[kind] || 0))); }
  function canBuyManager(kind) { var m = MANAGERS[kind]; return !!m && (S.managers[kind] || 0) < m.max && S.money >= managerCost(kind); }
  function buyManager(kind) { if (!canBuyManager(kind)) return false; S.money -= managerCost(kind); S.managers[kind] = (S.managers[kind] || 0) + 1; save(); return true; }
  function mgrMul(kind) { var m = MANAGERS[kind]; return 1 + m.per * (S.managers[kind] || 0); }

  // ---- contracts (per-port standing orders: deliver a stockpile for a premium lump sum) ----
  var ORDER_LABELS = ['Royal Galley', 'Spice Merchant', 'Naval Quartermaster', 'Coastal Guild', 'Foreign Envoy', 'Cannery Co.', 'Harbour Exchange', 'Northern Traders'];
  function basePrice(res) { for (var k in BT) { var t = BT[k]; if (t.sells && t.sells.from === res) return t.sells.price; } return 5; }
  function genContract() {
    var pool = ['fish']; if (S.era >= 2) { pool.push('timber', 'goods'); } if (S.era >= 1) pool.push('fish');
    var seq = (CUR.contractSeq = (CUR.contractSeq || 0) + 1);
    var res = pool[(seq * 1) % pool.length];
    var base = res === 'goods' ? 24 : 70;
    var amt = Math.round(base * (1 + S.era * 0.55) * (0.8 + ((seq * 7) % 5) * 0.12));
    var premium = 1.7 + ((seq * 3) % 4) * 0.15;                      // 1.7x .. 2.15x passive price
    var reward = Math.round(amt * basePrice(res) * premium);
    var who = ORDER_LABELS[(seq * 5) % ORDER_LABELS.length];
    return { id: CUR.id + 'c' + seq, who: who, res: res, amt: amt, reward: reward };
  }
  function ensureContracts() { if (!CUR.contracts) CUR.contracts = []; var want = 3 + (META.contractSlots || 0), guard = 0; while (CUR.contracts.length < want && guard++ < 20) CUR.contracts.push(genContract()); }
  function findContract(id) { for (var i = 0; i < (CUR.contracts || []).length; i++) if (CUR.contracts[i].id === id) return i; return -1; }
  function canFulfill(id) { var i = findContract(id); return i >= 0 && CUR.res[CUR.contracts[i].res] >= CUR.contracts[i].amt; }
  function fulfillContract(id) {
    if (!CUR || !canFulfill(id)) return 0;
    var i = findContract(id), c = CUR.contracts[i];
    CUR.res[c.res] = Math.max(0, CUR.res[c.res] - c.amt);
    S.money += c.reward; S.lifetimeMoney = (S.lifetimeMoney || 0) + c.reward;
    CUR.contracts.splice(i, 1); ensureContracts(); save();
    return c.reward;
  }
  function rerollContract(id) { if (!CUR) return false; var i = findContract(id); if (i < 0) return false; CUR.contracts.splice(i, 1); ensureContracts(); save(); return true; }

  // ---- trade network (routes ship surplus between ports + pay a tariff; volume levels the net) ----
  var ROUTE_BASE_CAP = 0.5, NET_XP_PER_UNIT = 0.4;
  function routeCap(level) { return ROUTE_BASE_CAP * level * (1 + 0.12 * ((S.network.level || 1) - 1)) * (META.routeMul || 1); }   // units/s
  function routeTariff(res) { return basePrice(res) * 0.06 * (1 + 0.05 * ((S.network.level || 1) - 1)); }    // money/unit
  function routeCost(level) { return Math.round(250 * Math.pow(1.7, level || 0)); }   // level=current; cost to reach level+1 (0=create)
  function maxRoutes() { return 2 + (S.network.level || 1); }
  function netNeed(level) { return Math.round(120 * Math.pow(1.5, (level || 1) - 1)); }
  function addNetXP(a) { S.network.xp = (S.network.xp || 0) + a; while (S.network.xp >= netNeed(S.network.level)) { S.network.xp -= netNeed(S.network.level); S.network.level++; } }
  function findRoute(id) { var rs = S.network.routes; for (var i = 0; i < rs.length; i++) if (rs[i].id === id) return i; return -1; }
  function hasRoute(a, b, res) { var rs = S.network.routes; for (var i = 0; i < rs.length; i++) if (rs[i].a === a && rs[i].b === b && rs[i].res === res) return true; return false; }
  function canAddRoute(a, b, res) {
    return !!(S.ports[a] && S.ports[b] && a !== b && BASE_CAP.hasOwnProperty(res) &&
      !hasRoute(a, b, res) && S.network.routes.length < maxRoutes() && S.money >= routeCost(0));
  }
  function addRoute(a, b, res) {
    if (!canAddRoute(a, b, res)) return false;
    S.money -= routeCost(0);
    S.network.routes.push({ id: 'r' + (S.network.seq = (S.network.seq || 0) + 1), a: a, b: b, res: res, level: 1 });
    save(); return true;
  }
  function upgradeRoute(id) {
    var i = findRoute(id); if (i < 0) return false; var r = S.network.routes[i];
    var c = routeCost(r.level); if (S.money < c) return false;
    S.money -= c; r.level++; save(); return true;
  }
  function removeRoute(id) { var i = findRoute(id); if (i < 0) return false; S.network.routes.splice(i, 1); save(); return true; }
  // ship resources along every route; returns tariff income to fold into the empire treasury
  function tickRoutes(dt) {
    var rs = S.network.routes, income = 0, shipped = 0;
    for (var i = 0; i < rs.length; i++) {
      var r = rs[i], pa = S.ports[r.a], pb = S.ports[r.b]; if (!pa || !pb) continue;
      var fb = Math.max(focusRouteMul(pa.focus || 'none'), focusRouteMul(pb.focus || 'none'));   // trade-focus ports ship more
      var want = routeCap(r.level) * fb * dt;
      var space = Math.max(0, capsOf(pb)[r.res] - (pb.res[r.res] || 0));
      var amt = Math.min(want, pa.res[r.res] || 0, space);
      if (amt <= 0) continue;
      pa.res[r.res] -= amt; pb.res[r.res] += amt;
      shipped += amt; income += amt * routeTariff(r.res);
    }
    if (shipped > 0) { addNetXP(shipped * NET_XP_PER_UNIT); if (S.stats) S.stats.shipped = (S.stats.shipped || 0) + shipped; }
    return income * fleetYieldMul('trade');   // Phase 17b: trade fleet tier rubber-bands route income
  }
  function networkView() {
    return {
      level: S.network.level, xp: Math.floor(S.network.xp || 0), need: netNeed(S.network.level),
      maxRoutes: maxRoutes(), routeCreateCost: routeCost(0),
      capPct: Math.round(12 * (S.network.level - 1)), tariffPct: Math.round(5 * (S.network.level - 1)), insurance: S.network.level >= 3,
      routes: (S.network.routes || []).map(function (r) {
        return { id: r.id, a: r.a, b: r.b, res: r.res, level: r.level, cap: +(routeCap(r.level)).toFixed(2), tariff: +(routeTariff(r.res)).toFixed(2), up: routeCost(r.level) };
      })
    };
  }

  // ---- hazards: storms damage a port's buildings + sink route cargo; market crashes floor a price.
  // Meaningful but never wipes money/era — you pay to repair and invest in defenses to weather them.
  var HAZARD = { green: 'Squall', mountain: 'Rockslide', desert: 'Sandstorm', tropical: 'Hurricane', nordic: 'Ice Storm' };
  function hzRand(a, b) { return (a + _rng() * (b - a)) * PACE * DIFF.gap; }   // PACE + difficulty stretch/shrink the gap between hazards, not their telegraph/strike
  function bhp(b) { return b.hp == null ? 100 : b.hp; }
  // Phase 17a: Sky Beacon (era7 defense) adds a THIRD defense stat alongside Sea Wall/Lighthouse —
  // a further storm-damage cut (strike() below) and a raid-survival edge (evData('raid')) — a late-
  // game defense tier so hazards stay a real (if shrinking) threat instead of trivial once maxed.
  function portDef(p) { var w = 0, l = 0, bcn = 0, B = p.buildings; for (var i = 0; i < B.length; i++) { if (B[i].type === 'seawall') w += B[i].level; else if (B[i].type === 'lighthouse') l += B[i].level; else if (B[i].type === 'sky_beacon') bcn += B[i].level; } return { wall: w, light: l, beacon: bcn }; }
  function strike(portId) {
    var p = S.ports[portId]; if (!p) return;
    var def = portDef(p);
    // Phase 17c: navy hazardResist (0.03/power) composes ADDITIVELY with every existing term —
    // sea wall + sky beacon + network insurance + Legacy — same Math.max(0.1, …) floor as before,
    // so navyPower()===0 (no navy, or a pre-17c migrated save) reproduces the exact old formula.
    var dmgF = Math.max(0.1, 1 - 0.16 * def.wall - 0.10 * def.beacon - 0.05 * ((S.network.level || 1) - 1) - (META.hazardResist || 0) - 0.03 * navyPower());   // sea wall + sky beacon + insurance + Legacy + navy
    var pool = []; for (var i = 0; i < p.buildings.length; i++) if (BT[p.buildings[i].type].cat !== 'defense') pool.push(i);
    var n = Math.min(pool.length, 1 + Math.floor(_rng() * 2)), damaged = 0;     // hit 1–2 buildings
    for (var k = 0; k < n && pool.length; k++) {
      var pick = pool.splice(Math.floor(_rng() * pool.length), 1)[0], b = p.buildings[pick];
      b.hp = clamp(bhp(b) - (25 + _rng() * 30) * dmgF * DIFF.severity, 0, 100); damaged++;   // difficulty amplifies storm damage
    }
    var lossMul = Math.max(0.2, 1 - 0.25 * def.light), sunk = 0;                        // lighthouse protects cargo
    var rs = S.network.routes;
    for (var r = 0; r < rs.length; r++) { if (rs[r].a === portId || rs[r].b === portId) { var res = rs[r].res, loss = (p.res[res] || 0) * 0.25 * lossMul; p.res[res] -= loss; sunk += loss; } }
    S.hazard.strikeId = (S.hazard.strikeId || 0) + 1;
    if (S.stats) S.stats.storms = (S.stats.storms || 0) + 1;
    S.hazard.last = { id: S.hazard.strikeId, port: portId, kind: HAZARD[portId] || 'Storm', damaged: damaged, sunk: Math.round(sunk), crash: false };
  }
  function tickHazard(dt) {
    if (dt >= 5 || !S.ports) return;                                                   // live-play only (offline stays a safe earn window)
    if (S.crash) { S.crash.t -= dt; if (S.crash.t <= 0) S.crash = null; }
    if (S.era < 1) return;                                                              // grace in the starter era
    var hz = S.hazard || (S.hazard = { t: 0, next: hzRand(70, 150), phase: 'idle', strikeId: 0, last: null });
    hz.t += dt;
    if (hz.phase === 'idle') {
      if (hz.t >= hz.next) {
        var founded = Object.keys(S.ports);
        if (!founded.length) { hz.t = 0; hz.next = hzRand(70, 150); return; }
        hz.port = founded[Math.floor(_rng() * founded.length)];
        hz.crash = _rng() < 0.22;
        hz.kind = hz.crash ? 'Market Crash' : (HAZARD[hz.port] || 'Storm');
        hz.phase = 'warn'; hz.warn = 6;
      }
    } else if (hz.phase === 'warn') {
      hz.warn -= dt;
      if (hz.warn <= 0) {
        if (hz.crash) { var rr = ['fish', 'timber', 'goods'][Math.floor(_rng() * 3)]; S.crash = { res: rr, t: 35 }; hz.strikeId = (hz.strikeId || 0) + 1; if (S.stats) S.stats.storms = (S.stats.storms || 0) + 1; hz.last = { id: hz.strikeId, crash: true, res: rr, kind: 'Market Crash', port: hz.port }; }
        else strike(hz.port);
        hz.phase = 'idle'; hz.t = 0; hz.next = hzRand(110, 230);
      }
    }
  }
  function crashMul(res) { return (S.crash && S.crash.res === res) ? 0.45 : 1; }

  // ---- avert (Phase 15b): pay to cancel a telegraphed hazard/crash outright, during its warn
  // phase only — the "stop it before it happens" ask from playtesters, sitting alongside (not
  // replacing) the existing repair/rebuild comeback path. Cost is a flat, era-scaled sum (not
  // tied to what would actually get hit) so it's a predictable insurance premium, not a gamble.
  // Tuning: 60×2^era. At era0 a single storm-hit building (e.g. a Jetty, cost 60) repairs for
  // ~£12-30 depending on how hard it got hit, and a strike can clip 1-2 buildings — so 60 sits at
  // roughly 1.5-2x a typical FULL repair bill for that era, comfortably below "just repair whatever
  // breaks" while still being a real spend. Doubling per era tracks how repair bills grow with
  // building cost/level without chasing the much steeper (5-7x) era-to-era jump in ERA_REQ money
  // gates, so averting stays a live option (not priced out) as the empire grows.
  function avertCost() { return Math.round(60 * Math.pow(2, S.era || 0)); }
  function avertHazard() {
    if (!S || !S.hazard || S.hazard.phase !== 'warn' || S.hazard.crash) return false;   // storm-only; crash uses avertCrash
    var cost = avertCost(); if (S.money < cost) return false;
    S.money -= cost;
    S.hazard.phase = 'idle'; S.hazard.t = 0; S.hazard.next = hzRand(110, 230); S.hazard.port = null; S.hazard.kind = null;
    S.stats.averted = (S.stats.averted || 0) + 1;
    save(); return true;
  }
  function avertCrash() {
    if (!S || !S.hazard || S.hazard.phase !== 'warn' || !S.hazard.crash) return false;   // crash-only; storm uses avertHazard
    var cost = avertCost(); if (S.money < cost) return false;
    S.money -= cost;
    S.hazard.phase = 'idle'; S.hazard.t = 0; S.hazard.next = hzRand(110, 230); S.hazard.port = null; S.hazard.kind = null;
    S.stats.averted = (S.stats.averted || 0) + 1;
    save(); return true;
  }
  // test/debug: force the hazard scheduler straight into its warn (telegraph) phase, skipping the
  // random wait — lets tests (and any future "storm's coming" UI hook) reach the avert-able window
  // deterministically instead of racing hzRand(). Mirrors the existing strikePort() debug hook.
  function forceWarn(portId, crash) {
    if (!S || !S.ports) return null;
    var founded = Object.keys(S.ports); if (!founded.length) return null;
    portId = (portId && S.ports[portId]) ? portId : founded[0];
    S.hazard.port = portId; S.hazard.crash = !!crash;
    S.hazard.kind = crash ? 'Market Crash' : (HAZARD[portId] || 'Storm');
    S.hazard.phase = 'warn'; S.hazard.warn = 6; S.hazard.t = 0;
    save(); return snapshot(S.active).hazard;
  }

  // ---- dynamic events: a second scheduler (alongside hazards) that fires varied surprises and
  // player-choice decisions. Never wipes money/era; ignoring a choice resolves to a safe default. ----
  var EV_DEFS = [
    { id: 'goldrush', kind: 'ambient', name: 'Gold Rush', minEra: 1, w: 3 },
    { id: 'festival', kind: 'ambient', name: 'Harbour Festival', minEra: 1, w: 2 },
    { id: 'castaway', kind: 'collect', name: 'Castaway Raft', minEra: 0, w: 2 },
    { id: 'raid', kind: 'choice', name: 'Pirate Raid', minEra: 2, w: 2 },
    { id: 'gamble', kind: 'choice', name: "Merchant's Gamble", minEra: 1, w: 2 },
    { id: 'commission', kind: 'choice', name: 'Royal Commission', minEra: 1, w: 2 },
    { id: 'smuggler', kind: 'choice', name: 'Smuggler’s Offer', minEra: 1, w: 2 }
  ];
  function evRand(a, b) { return (a + _rng() * (b - a)) * PACE * DIFF.gap; }   // PACE + difficulty stretch/shrink the gap between events, not their resolve timer
  function evDef(id) { for (var i = 0; i < EV_DEFS.length; i++) if (EV_DEFS[i].id === id) return EV_DEFS[i]; return null; }
  // Portal content policy: some hosts (Poki) forbid ANY wager/chance mechanic regardless of currency.
  // A build can EXCLUDE specific events from ever being scheduled — the code (evData/resolveEvent)
  // stays intact, the event is simply never rolled. Set by the Poki build (window.__POKI_BUILD__ →
  // drop 'gamble') or explicitly via HARBOR_SIM.setEventExclusions([...]) for tests.
  var EV_EXCLUDE = {};
  try { if (typeof window !== 'undefined' && window.__POKI_BUILD__) EV_EXCLUDE.gamble = true; } catch (e) {}
  function setEventExclusions(ids) { EV_EXCLUDE = {}; if (ids) for (var i = 0; i < ids.length; i++) EV_EXCLUDE[ids[i]] = true; }
  function evPick() {
    var elig = EV_DEFS.filter(function (e) { return S.era >= e.minEra && !EV_EXCLUDE[e.id]; });
    var pool = elig.filter(function (e) { return e.id !== (S.evt.lastId || ''); });
    if (!pool.length) pool = elig; if (!pool.length) return null;
    var ew = function (e) { return e.id === 'raid' ? e.w * DIFF.raidW : e.w; };   // difficulty weights pirate raids up (more wars)
    var tot = 0; pool.forEach(function (e) { tot += ew(e); });
    var r = _rng() * tot;
    for (var i = 0; i < pool.length; i++) { r -= ew(pool[i]); if (r <= 0) return pool[i]; }
    return pool[pool.length - 1];
  }
  function evData(def) {
    var era = S.era, money = S.money, d = portDef(CUR || { buildings: [] });
    if (def.id === 'goldrush') return { mult: 1.8, secs: 30 };
    if (def.id === 'festival') return { mult: 1.5, secs: 30, fever: true };
    if (def.id === 'castaway') return {};
    // Phase 17c: navy adds +0.08/power ON TOP of the pre-17c wall/light/beacon odds — that base term
    // keeps its OWN original clamp(0.45,0.92) unchanged (so navyPower()===0 reproduces the exact
    // pre-17c winOdds for any wall/light/beacon combo, even a maxed one that would otherwise have
    // clamped at 0.92), then the navy bonus is added and the TOTAL gets its own, higher 0.95 ceiling.
    if (def.id === 'raid') {
      var raidBase = clamp(0.45 + 0.12 * d.wall + 0.06 * d.light + 0.08 * d.beacon, 0.45, 0.92);
      return { tribute: Math.round(Math.max(30, Math.min(money * 0.12, 60 * Math.pow(2, era)))), winOdds: clamp(raidBase + 0.08 * navyPower(), 0.45, 0.95) };
    }
    if (def.id === 'gamble') return { wager: Math.round(Math.max(40, Math.min(money * 0.15, 90 * Math.pow(2, era)))), odds: 0.6 };
    if (def.id === 'commission') { var res = era >= 2 ? ['fish', 'timber', 'goods'][Math.floor(_rng() * 3)] : 'fish'; var amt = Math.round(40 * (1 + era * 0.6)); return { res: res, amt: amt, reward: Math.round(amt * basePrice(res) * 2.4) }; }
    if (def.id === 'smuggler') { var sr = era >= 2 ? ['fish', 'timber', 'goods'][Math.floor(_rng() * 3)] : 'fish'; var sa = Math.round(60 * (1 + era * 0.7)); return { res: sr, amt: sa, cost: Math.round(sa * basePrice(sr) * 0.55) }; }
    return {};
  }
  function applyAmbient(ev) { if (ev.id === 'goldrush' || ev.id === 'festival') setBoost(ev.data.mult, ev.data.secs); }
  function fireEvent(id) {
    if (!S) return null; setActive(S.active);
    var def = evDef(id); if (!def) return null;
    S.evt.seq = (S.evt.seq || 0) + 1;
    // Phase 17c: navy auto-defense — a raid never even opens a modal once navyPower() catches up
    // to raidStrength(): instant victory, half the tribute it would have demanded as loot, no risk.
    if (def.id === 'raid' && navyPower() >= raidStrength()) {
      var rd = evData(def), loot = Math.round(rd.tribute * 0.5);
      S.money += loot; S.lifetimeMoney = (S.lifetimeMoney || 0) + loot;
      S.stats.raidsRepelled = (S.stats.raidsRepelled || 0) + 1;
      S.evt.lastId = def.id;
      S.lastNavyRepel = { seq: S.evt.seq, loot: loot };
      save();
      return { id: def.id, kind: 'auto', name: def.name, seq: S.evt.seq, auto: true, loot: loot };
    }
    S.evt.active = { id: def.id, kind: def.kind, name: def.name, seq: S.evt.seq, ttl: def.kind === 'ambient' ? 7 : 40, data: evData(def) };
    S.evt.lastId = def.id;
    if (def.kind === 'ambient') applyAmbient(S.evt.active);
    save(); return S.evt.active;
  }
  function autoResolveEvent(ev) {                                       // safe, non-punishing timeout defaults
    if (ev.id === 'raid') S.money = Math.max(0, S.money - Math.round(ev.data.tribute * 0.5));
  }
  function tickEvents(dt) {
    if (dt >= 5 || !S.ports || !S.founded) return;                     // live-play only (offline is a safe window)
    var e = S.evt; e.t += dt;
    if (e.active) {
      e.active.ttl -= dt;
      if (e.active.ttl <= 0) { if (e.active.kind === 'choice') autoResolveEvent(e.active); e.active = null; e.t = 0; e.next = evRand(70, 150); }
      return;
    }
    if (S.era < 1 && _rng() > 0.4) { /* go easy in starter era */ }
    if (e.t >= e.next) { var def = evPick(); e.t = 0; e.next = evRand(95, 200); if (def) fireEvent(def.id); }
  }
  // player resolves the active choice/collect event; returns an outcome descriptor for the UI layer
  function resolveEvent(choice) {
    if (!S || !S.evt || !S.evt.active) return null;
    setActive(S.active);
    var ev = S.evt.active, out = { id: ev.id, ok: true, cash: 0, crate: 0 };
    if (ev.id === 'castaway') { out.cash = Math.round(Math.max(40, S.money * 0.06)); S.money += out.cash; out.crate = _rng() < 0.5 ? 1 : 0; out.text = 'Salvaged the drifting raft!'; }
    else if (ev.id === 'raid') {
      if (choice === 0) { out.cash = -ev.data.tribute; S.money = Math.max(0, S.money - ev.data.tribute); out.text = 'Tribute paid — they sail on.'; }
      else if (_rng() < ev.data.winOdds) { out.cash = ev.data.tribute * 2; S.money += out.cash; out.crate = 1; out.win = true; out.text = 'Routed them and seized loot!'; }
      else { strike(S.active); out.win = false; out.text = 'They breached the harbour!'; }
    }
    else if (ev.id === 'gamble') {
      if (choice === 0) { if (_rng() < ev.data.odds) { out.cash = ev.data.wager; S.money += out.cash; out.win = true; out.text = 'The venture paid off!'; } else { out.cash = -ev.data.wager; S.money = Math.max(0, S.money - ev.data.wager); out.win = false; out.text = 'The ship never returned…'; } }
      else out.text = 'Declined the wager.';
    }
    else if (ev.id === 'commission') {
      if (choice === 0) { var p = CUR; if (p && (p.res[ev.data.res] || 0) >= ev.data.amt) { p.res[ev.data.res] -= ev.data.amt; out.cash = ev.data.reward; S.money += out.cash; out.text = 'Commission fulfilled!'; } else { out.ok = false; out.text = 'Not enough ' + ev.data.res + '.'; return out; } }
      else out.text = 'Declined the commission.';
    }
    else if (ev.id === 'smuggler') {
      if (choice === 0) { if (S.money >= ev.data.cost) { S.money -= ev.data.cost; var sp = CUR; if (sp) sp.res[ev.data.res] = (sp.res[ev.data.res] || 0) + ev.data.amt; out.cash = -ev.data.cost; out.text = 'Contraband stowed below decks.'; } else { out.ok = false; out.text = 'Not enough cash.'; return out; } }
      else out.text = 'Waved the smuggler off.';
    }
    if (out.cash > 0) S.lifetimeMoney = (S.lifetimeMoney || 0) + out.cash;
    S.evt.lastId = ev.id; S.evt.active = null; S.evt.t = 0; S.evt.next = evRand(95, 200);
    save(); return out;
  }

  // ---- expeditions: timed voyages that resolve on wall-clock time, so they finish while you're
  // away (no tick needed — ready when now() >= endsAt). Send a ship, wait, collect a reward roll. ----
  var DESTINATIONS = [
    { id: 'cove', name: 'Smuggler’s Cove', tier: 1, secs: 120 },
    { id: 'reef', name: 'Coral Reef', tier: 2, secs: 360 },
    { id: 'isle', name: 'Lost Isle', tier: 3, secs: 900 },
    { id: 'trench', name: 'The Deep Trench', tier: 4, secs: 2400 }
  ];
  function destDef(id) { for (var i = 0; i < DESTINATIONS.length; i++) if (DESTINATIONS[i].id === id) return DESTINATIONS[i]; return null; }
  function voyageSlots() { return 1 + Math.min(2, Math.floor(empireEra() / 2)) + (META.voyageSlots || 0); }   // expeditions are empire-wide → scale on empire era
  function voyageCost(d) { return Math.round(120 * d.tier * (1 + (S.era || 0) * 0.5)); }
  function canStartVoyage(id) { var d = destDef(id); return !!(d && S && S.money >= voyageCost(d) && (S.voyages || []).length < voyageSlots()); }
  function startVoyage(id) {
    var d = destDef(id); if (!canStartVoyage(id)) return false;
    S.money -= voyageCost(d); S.voyages = S.voyages || [];
    S.voyages.push({ id: d.id, startedAt: now(), endsAt: now() + d.secs * 1000 / (META.voyageSpeed || 1), seq: (S.voyageSeq = (S.voyageSeq || 0) + 1) });
    save(); return true;
  }
  function voyageReady(v) { return now() >= v.endsAt; }
  function rollVoyage(d) {
    var era = S.era || 0, cost = voyageCost(d), out = { cash: 0, res: null, crate: 0, relic: 0 };
    // Flagship capstone (META.voyageYield) and the Phase 17b expedition fleet tier COMPOSE
    // multiplicatively (both are "richer hauls" levers, from different systems — prestige vs. spend).
    out.cash = Math.round(cost * (2.2 + d.tier * 0.4) * (0.85 + _rng() * 0.5) * (1 + (META.voyageYield || 0)) * fleetYieldMul('expedition'));
    if (_rng() < 0.5) { var r = ['fish', 'timber', 'goods'][Math.floor(_rng() * 3)]; out.res = {}; out.res[r] = Math.round(20 * d.tier * (1 + era * 0.4)); }
    if (_rng() < 0.12 * d.tier) out.crate = 1;
    if (_rng() < 0.05 * d.tier) out.relic = 1;                  // relics wired up in Phase 7c
    return out;
  }
  function collectVoyage(seq) {
    if (!S || !S.voyages) return null;
    var idx = -1; for (var i = 0; i < S.voyages.length; i++) if (S.voyages[i].seq === seq) idx = i;
    if (idx < 0) return null;
    var v = S.voyages[idx]; if (!voyageReady(v)) return null;
    if (v.id === UNCHARTED_ID) {           // Phase 15c: discovery voyage — no cash/res roll, just unlocks
      S.voyages.splice(idx, 1); save();
      return { id: UNCHARTED_ID, name: 'Uncharted Waters', discover: true, unlockEra: v.unlockEra, cash: 0, res: null, crate: 0, relic: 0 };
    }
    var d = destDef(v.id); if (!d) return null;
    var out = rollVoyage(d); out.id = v.id; out.name = d.name; out.tier = d.tier;
    S.money += out.cash; S.lifetimeMoney = (S.lifetimeMoney || 0) + out.cash;
    if (out.res) { var p = S.ports[S.active]; if (p) for (var k in out.res) p.res[k] = (p.res[k] || 0) + out.res[k]; }
    S.voyages.splice(idx, 1); save(); return out;
  }
  function voyageState() {
    var active = (S.voyages || []).map(function (v) {
      var d = destDef(v.id), rem = Math.max(0, Math.ceil((v.endsAt - now()) / 1000)), isU = v.id === UNCHARTED_ID;
      return { seq: v.seq, id: v.id, name: d ? d.name : (isU ? 'Uncharted Waters' : v.id), tier: d ? d.tier : 0, uncharted: isU, total: d ? d.secs : (v.secs || 1), remaining: rem, ready: rem <= 0 };
    });
    return {
      slots: voyageSlots(), used: active.length, ready: active.filter(function (a) { return a.ready; }).length,
      active: active,
      dests: DESTINATIONS.map(function (d) { return { id: d.id, name: d.name, tier: d.tier, secs: d.secs, cost: voyageCost(d), can: canStartVoyage(d.id) }; })
    };
  }

  // ---- Phase 15c: Uncharted Waters — a special, distinguishable voyage (dest kind 'uncharted')
  // that discovers the next locked world instead of paying out cash/res. Uses the exact same
  // wall-clock endsAt + startVoyage/collectVoyage plumbing as normal expeditions (survives reload
  // and offline), so nothing new needed for persistence. sim.js stays biome-agnostic: game.js
  // decides WHICH world is next (walking HARBOR_BIOME_ORDER against its own `unlocked` list) and
  // passes that world's unlockEra in for the cost roll; sim only tracks the generic voyage.
  // Tuning: cost 400×3^(unlockEra-1) — steep and era-scaled, the real "go discover a new coast"
  // decision (vs. the much smaller 150×2^era colony-founding fee once you get there); duration is
  // 1.75× the longest ordinary voyage (The Deep Trench, 2400s) ≈ 70 real minutes, so it reads as a
  // genuine expedition into the unknown rather than a quick errand. See the Phase 15c commit body.
  var UNCHARTED_ID = 'uncharted', UNCHARTED_DUR_MUL = 1.75;
  function unchartedSecs() {
    var maxSecs = 0; for (var i = 0; i < DESTINATIONS.length; i++) if (DESTINATIONS[i].secs > maxSecs) maxSecs = DESTINATIONS[i].secs;
    return Math.round(maxSecs * UNCHARTED_DUR_MUL);
  }
  function unchartedCost(unlockEra) { return Math.round(400 * Math.pow(3, Math.max(0, (unlockEra || 1) - 1))); }
  function canStartUncharted(unlockEra) { return !!S && S.money >= unchartedCost(unlockEra) && (S.voyages || []).length < voyageSlots(); }
  function startUncharted(unlockEra) {
    if (!canStartUncharted(unlockEra)) return false;
    var cost = unchartedCost(unlockEra), secs = unchartedSecs();
    S.money -= cost; S.voyages = S.voyages || [];
    S.voyages.push({ id: UNCHARTED_ID, startedAt: now(), endsAt: now() + secs * 1000 / (META.voyageSpeed || 1), seq: (S.voyageSeq = (S.voyageSeq || 0) + 1), secs: secs, unlockEra: unlockEra });
    save(); return true;
  }

  // ---- repair / rebuild (the comeback money sink; salvage-discounted vs a fresh build) ----
  function repairCost(b) { var t = BT[b.type], miss = (100 - bhp(b)) / 100; return Math.max(1, Math.round(t.cost * 0.5 * miss * Math.pow(1.3, (b.level || 1) - 1))); }
  function canRepair(i) { var b = CUR && CUR.buildings[i]; return !!b && bhp(b) < 100 && S.money >= repairCost(b); }
  function repair(i) { if (!canRepair(i)) return false; var b = CUR.buildings[i]; S.money -= repairCost(b); b.hp = 100; save(); return true; }

  // ---- core tick ----
  // Advance one port; mutate its res/demand/pop; return the money delta it contributed to the empire.
  function tickPort(dt) {
    var port = CUR; if (!port) return 0;
    var sp = spec(port.id);
    var cap = caps(), p = pop(), j = jobs();
    // labour: housing feeds crew. A 12% floor (the founders themselves) keeps a port from ever
    // soft-locking at zero output, and softens the blow when a storm wrecks your cottages.
    var labor = j > 0 ? clamp(p / j, 0.12, 1) : 1;
    labor = Math.min(1.25, labor * mgrMul('labour'));
    // Phase 9a: composition synergies + port specialisation fold in alongside the existing multipliers
    var syn = synergyMul(port), focus = port.focus || 'none';
    var prodMul = mgrMul('fishing') * (META.prodMul || 1) * (TIDE.prod || 1) * boostMul() * syn.prod;   // managers × Legacy × tide × crate surge × synergy
    var salesMul = mgrMul('sales') * (META.sellMul || 1) * syn.sales * focusSalesMul(focus) * DIFF.income;   // difficulty scales money income (wages unchanged → tighter margins)
    // soft-cap taper: production slows as a store fills (1.0 empty -> 0.35 full) so caps bite gently
    var taper = {};
    for (var r0 in cap) taper[r0] = 1 - 0.65 * clamp((port.res[r0] || 0) / cap[r0], 0, 1);
    var add = { fish: 0, timber: 0, goods: 0 }, money = 0;
    var soldR = { fish: 0, timber: 0, goods: 0 }, revR = { fish: 0, timber: 0, goods: 0 };
    for (var i = 0; i < port.buildings.length; i++) {
      var b = port.buildings[i], t = BT[b.type]; if (t.cat === 'defense') continue;
      var m = lvlMul(t, b.level) * (bhp(b) / 100);                   // storm-damaged buildings produce less (wrecked = 0)
      if (t.prod) for (var r in t.prod) add[r] += t.prod[r] * m * labor * prodMul * focusProdMul(focus, r) * fleetProdMul(r) * sp[r] * taper[r] * dt;
      if (t.convert) { var avail = port.res[t.convert.from] + add[t.convert.from]; var amt = Math.min(avail, t.convert.rate * m * labor * prodMul * focusProdMul(focus, t.convert.to) * (sp[t.convert.to] || 1) * taper[t.convert.to] * dt); add[t.convert.from] -= amt; add[t.convert.to] += amt; }
      if (t.sells) { var f = t.sells.from, have = port.res[f] + add[f]; var sold = Math.min(have, t.sells.rate * m * labor * dt); add[f] -= sold; soldR[f] += sold; revR[f] += sold * t.sells.price; }
      if (t.money) money += t.money * m * labor * salesMul * dt;
    }
    // dynamic demand (per port): dumping one resource softens its local price; recovers over time.
    var ease = 1 - Math.exp(-dt / 60);
    for (var s in soldR) {
      var rate = soldR[s] / dt;
      var target = DEMAND_SOFT / (DEMAND_SOFT + rate);
      port.demand[s] = clamp((port.demand[s] || 1) + (target - (port.demand[s] || 1)) * ease, 0.25, 1);
      money += revR[s] * port.demand[s] * salesMul * crashMul(s) * (TIDE.sell[s] || 1);   // crash floors / daily tide boosts a price
    }
    // wages: every working crew costs money/s; Foreman trims the bill
    money -= WAGE * Math.min(p, j) * dt * Math.max(0.2, 1 - 0.10 * (S.managers.labour || 0));
    for (var k in add) { port.res[k] = clamp((port.res[k] + add[k]) || 0, 0, cap[k]); }
    port.pop = p;
    return money;
  }
  function tick(dt) {
    if (!S || !S.ports || dt <= 0) return;
    dt = Math.min(dt, 36000);                                       // safety clamp (10h max chunk)
    if (BOOST.t > 0) { BOOST.t -= dt; if (BOOST.t <= 0) { BOOST.mult = 1; BOOST.t = 0; } }   // decay crate surge
    var delta = 0;
    for (var id in S.ports) { CUR = S.ports[id]; delta += tickPort(dt); }
    setActive(S.active);                                            // restore scope to the active port
    delta += tickRoutes(dt);                                        // trade routes ship cargo + pay tariffs
    tickHazard(dt);                                                 // storms / market crashes (live play only)
    tickEvents(dt);                                                 // dynamic events (gold rush, raids, commissions…)
    if (delta > 0) S.lifetimeMoney = (S.lifetimeMoney || 0) + delta;
    S.money = Math.max(0, (S.money + delta) || 0);
  }

  // ---- actions (operate on the active port) ----
  function canBuild(type) {
    var t = BT[type];
    return !!CUR && !!t && S.era >= t.era && !blocked(type) && countOf(type) < bmax(type) &&
      (t.cat === 'defense' || slotsUsed(CUR) < slotCap()) && S.money >= buildCost(type);
  }
  function build(type) { if (!canBuild(type)) return false; S.money -= buildCost(type); CUR.buildings.push({ type: type, level: 1, hp: 100 }); save(); return true; }
  function canUpgrade(i) { var b = CUR && CUR.buildings[i]; return !!b && b.level < lvlCapFor(b.type) && S.money >= upCost(b); }
  function upgrade(i) { if (!canUpgrade(i)) return false; var b = CUR.buildings[i]; S.money -= upCost(b); b.level++; save(); return true; }
  // pick a port's specialisation focus (none|fishing|industry|trade); default port is the active one
  function setFocus(portId, focus) {
    if (!S || !S.ports) return false;
    var pid = (portId == null) ? S.active : portId, p = S.ports[pid];
    if (!p || FOCUS_IDS.indexOf(focus) < 0) return false;
    p.focus = focus; save(); return true;
  }

  function canAdvance() {
    if (!S || !CUR) return false;                                    // no era cap — endless; needs an active harbour
    var req = eraReq(S.era); if (!req) return false;                 // S.era = the ACTIVE harbour's era
    if (S.money < req.money) return false;                           // money is the shared empire treasury
    // Per-port era: advancing THIS harbour needs THIS harbour's own buildings — a fresh colony can't
    // ride your other ports' buildings to skip ahead. (Single-port play is identical to before.)
    // v90: the required buildings must be MAXED for this age (built AND upgraded to the era level cap),
    // not merely present — reaching the caps is the gate to the next era.
    if (req.need) { for (var k in req.need) if (countAtCap(CUR, k) < req.need[k]) return false; }
    return true;
  }
  function advanceEra() { if (!canAdvance()) return false; CUR.era = (CUR.era || 0) + 1; S.era = CUR.era; save(); return true; }
  // v90: structured "what do I need to reach the next age" — money + each required building MAXED to
  // the era cap — so game.js can render an unambiguous ✓/✗ checklist rather than a bare money bar.
  function advanceInfo() {
    if (!S || !CUR) return null;
    var req = eraReq(S.era), cap = lvlCap();
    if (!req) return { max: true, nextEra: null, cap: cap, money: null, builds: [], ok: false };
    var money = { have: Math.floor(S.money), need: req.money, ok: S.money >= req.money }, builds = [];
    if (req.need) for (var k in req.need) { var have = countAtCap(CUR, k); builds.push({ type: k, name: (BT[k] ? BT[k].name : k), need: req.need[k], have: have, cap: lvlCapFor(k), ok: have >= req.need[k] }); }
    var ok = money.ok && builds.every(function (b) { return b.ok; });
    return { max: false, nextEra: eraName(S.era + 1), cap: cap, money: money, builds: builds, ok: ok };
  }

  // ---- found a world's port ----
  // Phase 15c: the FIRST port an empire ever founds is free (the starting village); every colony
  // after that charges a real, era-scaled fee — "founding a new colony" is now a deliberate spend,
  // not a free byproduct of unlocking a world. Tuning: 150×2^era — deliberately modest next to the
  // Uncharted Waters discovery cost (400×3^(unlockEra-1)): discovery is the steep, rare gate;
  // founding is a smaller "commit to developing this coast" toll you can pay every run. See the
  // Phase 15c commit body for the numbers this was checked against.
  function isFirstPort() { return !S || !S.ports || Object.keys(S.ports).length === 0; }
  function colonyCost() { return Math.round(150 * Math.pow(2, empireEra())); }   // founding cost scales with your empire's advancement, not the fresh colony you're viewing
  function foundCost() { return isFirstPort() ? 0 : colonyCost(); }
  function canFoundPort() { return isFirstPort() || (S && S.money >= colonyCost()); }
  // free: internal reconciliation (e.g. re-founding a colony you already discovered, after a
  // prestige reset wipes ports) bypasses the fee — it's restoring state you already earned, not a
  // new founding decision. Only the explicit "Found colony" UI action omits `free`.
  function foundPort(id, free) {
    if (!S) S = fresh();
    id = id || S.active || 'green';
    if (!S.ports[id]) {
      if (!free && !isFirstPort()) {
        var cost = colonyCost();
        if (S.money < cost) return null;
        S.money -= cost;
      }
      S.ports[id] = freshPort(id); CUR = S.ports[id]; ensureContracts();
    }
    S.founded = true; setActive(id); save();
    return snapshot(id);
  }

  // ---- persistence + offline ----
  function key() { return 'sim'; }
  function save() { if (R && S) R.set('harbor', key(), S); }
  function load() {
    var d = R && R.get('harbor', key(), null);
    if (d && (d.ports || d.buildings)) { S = d; patch(); }
    else { S = fresh(); setActive('green'); }
    return S;
  }
  // v86: offline/idle earnings REMOVED. This no longer ticks the economy forward for time-away — it
  // only stamps lastSeen (still used by the once-per-day login-streak cadence). Kept as a no-op so any
  // caller/save path stays safe; returns 0 elapsed-earning seconds.
  function applyOffline() {
    if (!S) return 0;
    S.lastSeen = now();
    return 0;
  }

  // ---- prestige (cash the run's lifetime earnings into permanent Legacy, then start anew) ----
  var PRESTIGE_THRESHOLD = 250000;   // first prestige unlocks ~Industrial Port (~45–60 min) so the loop hooks early
  function prestigeGain() { return S ? Math.floor(Math.pow((S.lifetimeMoney || 0) / PRESTIGE_THRESHOLD, 0.5) * 8 * DIFF.prestigeMul) : 0; }   // harder difficulty banks more Legacy — the reward for strategy
  function canPrestige() { return !!S && (S.lifetimeMoney || 0) >= PRESTIGE_THRESHOLD && prestigeGain() >= 1; }
  function resetRun() { S = fresh(); setActive('green'); save(); return snapshot(); }   // wipe the run; META start bonuses apply via fresh()

  // ---- views ----
  function managerView() {
    var out = {};
    for (var k in MANAGERS) { var m = MANAGERS[k]; out[k] = { name: m.name, desc: m.desc, lvl: (S.managers[k] || 0), max: m.max, cost: managerCost(k), can: canBuyManager(k) }; }
    return out;
  }
  function portList() {
    var out = [];
    for (var id in S.ports) { var pt = S.ports[id]; out.push({ id: id, hint: spec(id).hint, buildings: pt.buildings.length, res: { fish: Math.floor(pt.res.fish), timber: Math.floor(pt.res.timber), goods: Math.floor(pt.res.goods) } }); }
    return out;
  }
  // Phase 17b: per-role fleet-registry view — tier owned, next-tier cost (null once maxed), the
  // live yield multiplier, and the two independent reasons a purchase can be unavailable (can't
  // afford vs. era not reached yet) so game.js's Registry panel can tell "Need £X" from "Requires
  // [Age]" without re-deriving the gating logic itself.
  function fleetView() {
    var out = {};
    FLEET_ROLES.forEach(function (role) {
      var tier = fleetTier(role), cost = fleetShipCost(role);
      out[role] = { tier: tier, cost: cost, mul: +fleetYieldMul(role).toFixed(3), can: canBuyShip(role), eraGated: fleetEraGated(role), maxed: cost == null, nextEra: cost == null ? null : eraName(tier + 1) };
    });
    return out;
  }
  function snapshot(id) {
    if (!S) return null;
    var pid = id || S.active, port = S.ports[pid] || null, prev = CUR, prevEra = S.era;
    CUR = port; if (port && typeof port.era === 'number') S.era = port.era;   // scope era to the queried harbour, restored below
    var v = {
      era: S.era, eraName: eraName(S.era), money: Math.floor(S.money),
      empireEra: empireEra(), empireEraName: eraName(empireEra()),    // per-port era: this harbour's age vs the empire's most advanced
      world: pid, worldHint: spec(pid).hint, spec: spec(pid),
      founded: S.founded, portFounded: !!port,
      foundCost: foundCost(), canFoundPort: canFoundPort(),           // Phase 15c: colony founding fee (0 for the empire's first port)
      canAdvance: canAdvance(), nextEra: eraName(S.era + 1), eraReq: eraReq(S.era),
      lvlCap: lvlCap(), advance: advanceInfo(),                        // v90: per-era upgrade ceiling + next-age requirement checklist

      managers: managerView(), lifetimeMoney: Math.floor(S.lifetimeMoney || 0),
      prestige: { gain: prestigeGain(), can: canPrestige(), threshold: PRESTIGE_THRESHOLD },
      network: networkView(), fleet: fleetView(), navy: navyView(),   // Phase 17c: navy defense-ladder view
      hazard: S.hazard ? { phase: S.hazard.phase || 'idle', port: S.hazard.port || null, kind: S.hazard.kind || null, in: Math.max(0, Math.ceil(S.hazard.warn || 0)), strikeId: S.hazard.strikeId || 0, last: S.hazard.last || null, avertCost: avertCost() } : { phase: 'idle', strikeId: 0, last: null, avertCost: avertCost() },
      crash: S.crash ? { res: S.crash.res, t: Math.ceil(S.crash.t) } : null,
      event: (S.evt && S.evt.active) ? { id: S.evt.active.id, name: S.evt.active.name, kind: S.evt.active.kind, seq: S.evt.active.seq, ttl: Math.max(0, Math.ceil(S.evt.active.ttl)), data: S.evt.active.data } : null,
      navyRepel: S.lastNavyRepel || null,   // Phase 17c: last auto-defended raid {seq,loot} — game.js banner watches this by seq
      voyages: voyageState(),
      stats: { storms: (S.stats && S.stats.storms) || 0, shipped: Math.floor((S.stats && S.stats.shipped) || 0), averted: (S.stats && S.stats.averted) || 0, shipsBought: (S.stats && S.stats.shipsBought) || 0, navyBought: (S.stats && S.stats.navyBought) || 0, raidsRepelled: (S.stats && S.stats.raidsRepelled) || 0, ports: Object.keys(S.ports).length },
      ports: portList()
    };
    if (port) {
      v.res = { fish: Math.floor(port.res.fish), timber: Math.floor(port.res.timber), goods: Math.floor(port.res.goods) };
      v.caps = caps(); v.pop = Math.floor(pop()); v.jobs = jobs();
      v.buildings = port.buildings.map(function (b, i) { var cp = lvlCapFor(b.type); return { i: i, type: b.type, name: BT[b.type].name, level: b.level, cap: cp, maxed: (b.level || 1) >= cp, up: upCost(b), hp: Math.round(bhp(b)), rep: bhp(b) < 100 ? repairCost(b) : 0, def: BT[b.type].cat === 'defense' }; });
      v.damaged = port.buildings.filter(function (b) { return bhp(b) < 100; }).length;
      v.counts = counts(); v.demand = { fish: port.demand.fish, timber: port.demand.timber, goods: port.demand.goods };
      v.contracts = port.contracts.map(function (c) { return { id: c.id, who: c.who, res: c.res, amt: c.amt, reward: c.reward, have: Math.floor(port.res[c.res] || 0), can: canFulfill(c.id) }; });
      v.synergies = synergyList(port); v.focus = port.focus || 'none';   // Phase 9a: composition bonuses + specialisation
      v.slotCap = slotCap(); v.slotsUsed = slotsUsed(port);          // Phase 15c: per-port building-slot ceiling (defenses exempt)
    } else {
      v.res = { fish: 0, timber: 0, goods: 0 }; v.caps = { fish: BASE_CAP.fish, timber: BASE_CAP.timber, goods: BASE_CAP.goods };
      v.pop = 0; v.jobs = 0; v.buildings = []; v.counts = {}; v.demand = { fish: 1, timber: 1, goods: 1 }; v.contracts = [];
      v.synergies = SYNERGY_DEFS.map(function (d) { return { id: d.id, name: d.name, effect: d.effect, chan: d.chan, active: false }; }); v.focus = 'none';
      v.slotCap = slotCap(); v.slotsUsed = 0;
    }
    CUR = prev; S.era = prevEra;
    return v;
  }

  g.HARBOR_SIM = {
    BT: BT, ERAS: ERAS, ERA_REQ: ERA_REQ, MANAGERS: MANAGERS, WORLD_SPEC: WORLD_SPEC, WORLD_ORDER: WORLD_ORDER,
    SYNERGY_DEFS: SYNERGY_DEFS, FOCUS_DEFS: FOCUS_DEFS, FOCUS_IDS: FOCUS_IDS,
    setFocus: setFocus,
    synergies: function (id) { var p = S && S.ports ? (S.ports[id || S.active] || null) : null; return p ? synergyList(p) : synergyList({ buildings: [] }); },
    synergyMul: function (id) { var p = S && S.ports ? (S.ports[id || S.active] || null) : null; return synergyMul(p || { buildings: [] }); },
    eraName: eraName, eraReq: eraReq,
    applyMeta: applyMeta, meta: function () { return META; }, setTide: setTide, setBoost: setBoost, boostT: function () { return BOOST.t; },
    boostMul: function () { return boostMul(); },   // Phase 12a: current effective boost multiplier (1 when inactive) — lets callers combine/stack sensibly
    __setRng: setRng,                                               // test-only: seed all gameplay RNG for deterministic tests
    setPace: setPace, pace: function () { return PACE; },           // Phase 15b: gap-roll multiplier (device pref, not saved)
    setDifficulty: setDifficulty, difficulty: difficultyView,       // Easy→Extreme: income/gap/severity/raid/offline/prestige scaling (device pref, not saved)
    prestigeGain: prestigeGain, canPrestige: canPrestige, resetRun: resetRun,
    buyManager: buyManager, canBuyManager: canBuyManager, managerCost: managerCost,
    fulfillContract: fulfillContract, canFulfill: canFulfill, rerollContract: rerollContract,
    addRoute: addRoute, canAddRoute: canAddRoute, hasRoute: function (a, b, res) { return S && S.network ? hasRoute(a, b, res) : false; }, upgradeRoute: upgradeRoute, removeRoute: removeRoute, routeCost: routeCost, network: networkView,
    repair: repair, canRepair: canRepair, repairCost: function (i) { return CUR && CUR.buildings[i] ? repairCost(CUR.buildings[i]) : 0; },
    // Phase 17b: fleet registry — buy/query the three ship-tier ladders
    FLEET_ROLES: FLEET_ROLES, FLEET_COST: FLEET_COST,
    fleetTier: fleetTier, fleetShipCost: fleetShipCost, canBuyShip: canBuyShip, buyShip: buyShip,
    fleetYieldMul: fleetYieldMul, fleet: fleetView,
    // Phase 17c: the Navy — buy/query the 5-tier defense ladder
    NAVY_CLASSES: NAVY_CLASSES, NAVY_COST: NAVY_COST, NAVY_ERA: NAVY_ERA,
    navyTier: navyTier, navyShipCost: navyShipCost, canBuyNavy: canBuyNavy, buyNavy: buyNavy,
    navyPower: navyPower, navy: navyView, raidStrength: function () { return S ? raidStrength() : 0; },
    strikePort: function (id) { if (S) { strike(id || S.active); save(); } },   // debug/test: force a storm strike now
    avertCost: function () { return S ? avertCost() : 0; }, avertHazard: avertHazard, avertCrash: avertCrash,
    forceWarn: forceWarn,                                           // debug/test: jump straight to the warn (avert-able) phase
    fireEvent: fireEvent, resolveEvent: resolveEvent, event: function () { return S && S.evt ? S.evt.active : null; },
    setEventExclusions: setEventExclusions, eventExcluded: function (id) { return !!EV_EXCLUDE[id]; },   // portal content policy (Poki drops 'gamble')
    __evPick: function () { var d = S ? evPick() : null; return d ? d.id : null; },   // test hook: one weighted event roll (respects exclusions)
    startVoyage: startVoyage, collectVoyage: collectVoyage, canStartVoyage: canStartVoyage, voyages: voyageState,
    unchartedCost: function (era) { return unchartedCost(era); }, unchartedSecs: unchartedSecs,           // Phase 15c: discovery expedition
    canStartUncharted: function (era) { return S ? canStartUncharted(era) : false; }, startUncharted: startUncharted,
    newGame: function () { S = fresh(); setActive('green'); save(); return snapshot(); },
    load: function () { load(); return snapshot(); },
    state: function (id) { return S ? snapshot(id) : null; },
    raw: function () { return S; },
    port: function (id) { return S && S.ports ? (S.ports[id || S.active] || null) : null; },
    setActive: function (id) { if (S) { setActive(id); save(); } },
    foundPort: foundPort, foundCost: function () { return S ? foundCost() : 0; }, canFoundPort: function () { return S ? canFoundPort() : true; },
    tick: function (dt) { tick(dt); },
    build: build, canBuild: canBuild, buildCost: buildCost, blocked: blocked,
    slotCap: function () { return S ? slotCap() : 0; },                // Phase 15c: per-port building-slot ceiling + usage
    slotsUsed: function (id) { var p = S && S.ports ? (S.ports[id || S.active] || null) : null; return p ? slotsUsed(p) : 0; },
    upgrade: upgrade, canUpgrade: canUpgrade, upCost: function (i) { return CUR && CUR.buildings[i] ? upCost(CUR.buildings[i]) : 0; },
    canAdvance: canAdvance, advanceEra: advanceEra,
    advanceInfo: function () { return S ? advanceInfo() : null; },     // v90: next-age requirement checklist (money + maxed buildings)
    lvlCap: function () { return S ? lvlCap() : LVL_CAP_BASE; },        // v90: current per-era upgrade level ceiling
    setFounded: function (v) { if (S) { S.founded = !!v; save(); } },
    setEra: function (n) { if (S) { S.era = Math.max(0, n | 0); if (CUR) CUR.era = S.era; save(); } },   // per-port era: debug/test hook advances the ACTIVE harbour
    save: save, applyOffline: applyOffline, mark: function () { if (S) { S.lastSeen = now(); save(); } }
  };
})(typeof window !== 'undefined' ? window : globalThis);
